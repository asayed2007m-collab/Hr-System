#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>
#include<QPushButton>
#include<QHBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
     ui->left_menu->hide();
    ui->stackedWidget->setCurrentIndex(0);
     ui->idEdit->setText(QString::number(nextID));
    ui->tableJobs->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
     ui->tableAllApplicant->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableAccepted->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
     ui->tableRejected->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_loginbtn_clicked()
{
    QString username = ui->userEdit->text();
    QString password = ui->passEdit->text();


    if (username == "admin" && password == "1234") {

        QMessageBox::information(this, "نجاح", "أهلاً بك في نظام HR Hub");


        ui->stackedWidget->setCurrentIndex(1);

        ui->left_menu->show();
    }
    else{
        QMessageBox::warning(this, "خطأ", "اسم المستخدم أو كلمة المرور غير صحيحة!");


        ui->passEdit->clear();
    }
}




void MainWindow::on_addjobBtn_clicked()
{

    ui->stackedWidget->setCurrentIndex(1);


}






void MainWindow::on_addapllicantptn_clicked()
{
 ui->stackedWidget->setCurrentIndex(2);


}








void MainWindow::on_saveapplicantBtn_clicked()
{



    int id = ui->idEdit->text().toInt();
    QString name = ui->nameEdit->text();
    int age = ui->ageSpinBox->value();
    QString job = ui->jobcombo->currentText();
    QString cv = ui->cvtextEdit->toPlainText();


    if (!name.isEmpty()) {

        Applicant temp(id, name, job, cv,age);



        allApplicants.append(temp);

        QMessageBox::information(this, "نجاح", "تم حفظ المتقدم بنجاح!");


        nextID++;
        ui->idEdit->setText(QString::number(nextID));

        // 4. تنظيف الخانات
        ui->nameEdit->clear();
        ui->cvtextEdit->clear();
        ui->ageSpinBox->setValue(0);
    } else {

    }
}


void MainWindow::on_savejobBtn_clicked()
{
    QString jobName = ui->jobnameEdit->text();

    if (!jobName.isEmpty()) {


        ui->jobcombo->addItem(jobName);


        QMessageBox::information(this, "تم الحفظ", "الوظيفة " + jobName + " أصبحت متاحة الآن في قائمة المتقدمين.");


        ui->jobnameEdit->clear();

    } else {

    }

}


void MainWindow::on_btn_showapplicants_clicked()
{

        ui->stackedWidget->setCurrentIndex(3);
        ui->tableAllApplicant->setRowCount(0);

        for(int i = 0; i < allApplicants.size(); i++) {
            int row = ui->tableAllApplicant->rowCount();
            ui->tableAllApplicant->insertRow(row);


            ui->tableAllApplicant->setItem(row, 0, new QTableWidgetItem(QString::number(allApplicants[i].getId())));


            ui->tableAllApplicant->setItem(row, 1, new QTableWidgetItem(allApplicants[i].getName()));


            ui->tableAllApplicant->setItem(row, 2, new QTableWidgetItem(QString::number(allApplicants[i].getAge())));


            ui->tableAllApplicant->setItem(row, 3, new QTableWidgetItem(allApplicants[i].getJob()));

            QPushButton* cvBtn = new QPushButton("👁️");
            ui->tableAllApplicant->setCellWidget(row, 4, cvBtn);
            connect(cvBtn, &QPushButton::clicked, [=](){
                QMessageBox::information(this, "CV Content", allApplicants[i].getCv());
            });
            QWidget* container = new QWidget();
            QHBoxLayout* layout = new QHBoxLayout(container);
            QPushButton* accBtn = new QPushButton("✅");
            QPushButton* rejBtn = new QPushButton("❌");

            layout->addWidget(accBtn);
            layout->addWidget(rejBtn);
            layout->setContentsMargins(0,0,0,0);
            container->setLayout(layout);
            ui->tableAllApplicant->setCellWidget(row, 5, container);

            connect(accBtn, &QPushButton::clicked, [=](){
                acceptedApplicants.append(allApplicants[i]);
                allApplicants.removeAt(i);
                on_btn_showapplicants_clicked();
            });

            connect(rejBtn, &QPushButton::clicked, [=](){
                rejectedApplicants.append(allApplicants[i]);
                allApplicants.removeAt(i);
                on_btn_showapplicants_clicked();
            });
        }


}


void MainWindow::on_btn_accepted_clicked()
{


        ui->stackedWidget->setCurrentIndex(4);

        ui->tableAccepted->setRowCount(0);

        for(int i = 0; i < acceptedApplicants.size(); i++) {
            int row = ui->tableAccepted->rowCount();
            ui->tableAccepted->insertRow(row);

            ui->tableAccepted->setItem(row, 0, new QTableWidgetItem(QString::number(acceptedApplicants[i].getId())));
            ui->tableAccepted->setItem(row, 1, new QTableWidgetItem(acceptedApplicants[i].getName()));
            ui->tableAccepted->setItem(row, 2, new QTableWidgetItem(QString::number(acceptedApplicants[i].getAge())));
            ui->tableAccepted->setItem(row, 3, new QTableWidgetItem(acceptedApplicants[i].getJob()));

            QPushButton* cvBtn = new QPushButton("👁️");
            ui->tableAccepted->setCellWidget(row, 4, cvBtn);
            connect(cvBtn, &QPushButton::clicked, [=](){
                QMessageBox::information(this, "CV Details", acceptedApplicants[i].getCv());
            });
        }

}


void MainWindow::on_btn_rejected_clicked()
{

        ui->stackedWidget->setCurrentIndex(5);

        ui->tableRejected->setRowCount(0);

        for(int i = 0; i < rejectedApplicants.size(); i++) {
            int row = ui->tableRejected->rowCount();
            ui->tableRejected->insertRow(row);
            ui->tableRejected->setItem(row, 0, new QTableWidgetItem(QString::number(acceptedApplicants[i].getId())));
            ui->tableRejected->setItem(row, 1, new QTableWidgetItem(rejectedApplicants[i].getName()));
            ui->tableRejected->setItem(row, 2, new QTableWidgetItem(QString::number(rejectedApplicants[i].getAge())));
            ui->tableRejected->setItem(row, 3, new QTableWidgetItem(rejectedApplicants[i].getJob()));


            QPushButton* cvBtn = new QPushButton("👁️");
            ui->tableRejected->setCellWidget(row, 4, cvBtn);
            connect(cvBtn, &QPushButton::clicked, [=](){
                QMessageBox::information(this, "Rejected Applicant CV", rejectedApplicants[i].getCv());
            });

    }

}





void MainWindow::on_btn_job_clicked()
{


        ui->stackedWidget->setCurrentIndex(6);
        ui->tableJobs->setRowCount(0);

        QStringList dynamicJobs;
        for(auto &a : allApplicants) if(!dynamicJobs.contains(a.getJob())) dynamicJobs.append(a.getJob());
        for(auto &a : acceptedApplicants) if(!dynamicJobs.contains(a.getJob())) dynamicJobs.append(a.getJob());
        for(auto &a : rejectedApplicants) if(!dynamicJobs.contains(a.getJob())) dynamicJobs.append(a.getJob());

        for (const QString &jobName : dynamicJobs) {
            int row = ui->tableJobs->rowCount();
            ui->tableJobs->insertRow(row);

            int pendingCount = 0, acceptedCount = 0, rejectedCount = 0;

            for(auto &a : allApplicants) if(a.getJob() == jobName) pendingCount++;
            for(auto &a : acceptedApplicants) if(a.getJob() == jobName) acceptedCount++;
            for(auto &a : rejectedApplicants) if(a.getJob() == jobName) rejectedCount++;


            int totalApplicants = pendingCount + acceptedCount + rejectedCount;


            ui->tableJobs->setItem(row, 0, new QTableWidgetItem(jobName));
            ui->tableJobs->setItem(row, 1, new QTableWidgetItem(QString::number(totalApplicants)));
            ui->tableJobs->setItem(row, 2, new QTableWidgetItem(QString::number(acceptedCount)));
            ui->tableJobs->setItem(row, 3, new QTableWidgetItem(QString::number(rejectedCount)));
        }

}



void MainWindow::on_btn_exit_clicked()
{

        QApplication::quit();

}

