#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

// الكلاس الأب (فيه البيانات بس)
class Applicant {
protected: // محمية بس الأبناء يقدروا يشوفوها
    int id;
    QString name;
    int age;
    QString job;
    QString cv;

public:
    Applicant(int _id, QString _name, QString _job, QString _cv,int _age)
        : id(_id), name(_name), job(_job), cv(_cv),age(_age) {}

    // Getters
    int getId() { return id; }
    QString getName() { return name; }
    QString getJob() { return job; }
    QString getCv() { return cv; }
    int getAge(){return age;}

    // دالة افتراضية (Virtual Function) للقرار
    virtual QString getType() { return "Pending"; }
};

// الكلاس الابن للمقبولين
class AcceptedApplicant : public Applicant {
public:
    AcceptedApplicant(const Applicant& other) : Applicant(other) {}

    // Polymorphism: بنغير وظيفة الدالة
    QString getType() override { return "Accepted"; }
};

// الكلاس الابن للمرفوضين
class RejectedApplicant : public Applicant {
public:
    RejectedApplicant(const Applicant& other) : Applicant(other) {}

    QString getType() override { return "Rejected"; }
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_loginbtn_clicked();



    void on_addjobBtn_clicked();



    void on_addapllicantptn_clicked();





    void on_saveapplicantBtn_clicked();

    void on_savejobBtn_clicked();

    void on_btn_showapplicants_clicked();

    void on_btn_accepted_clicked();

    void on_btn_rejected_clicked();

    ;

    void on_btn_job_clicked();

    void on_btn_exit_clicked();

private:
    Ui::MainWindow *ui;
    QVector<Applicant> allApplicants;
    int nextID=1;
    QVector<Applicant> acceptedApplicants;
    QVector<Applicant> rejectedApplicants;
};
#endif // MAINWINDOW_H
